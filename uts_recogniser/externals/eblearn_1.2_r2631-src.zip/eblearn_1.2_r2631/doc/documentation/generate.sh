#!/bin/sh

doxygen Doxyfile.libeblearn
doxygen Doxyfile.libidx
doxygen Doxyfile.libeblearntools
doxygen Doxyfile.libeblearngui
doxygen Doxyfile.libidxgui
