/***************************************************************************
 *   Copyright (C) 2012 by Soumith Chintala *
 *   soumith@gmail.com *
 *   All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Redistribution under a license not approved by the Open Source
 *       Initiative (http://www.opensource.org) must display the
 *       following acknowledgement in all advertising material:
 *        This product includes software developed at the Courant
 *        Institute of Mathematical Sciences (http://cims.nyu.edu).
 *     * The names of the authors may not be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ThE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ***************************************************************************/

#ifndef THOPS_HPP_
#define THOPS_HPP_

//#include "numerics.h"
//#include "stl.h"

#ifdef __TH__
#include "idx.h"

namespace ebl {

  template <typename T>
  void th_add(idx<T> &in, idx<T> &out) {
    eblerror("th_add in-place : type not available for TH. Available types are float32, float64");
  }


  template <typename T>
  void th_add(idx<T> &in, idx<T> &in2, idx<T> &out) {
    eblerror("th_add not-in-place : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_copy(idx<T> &in, idx<T> &out) {
    eblerror("th_copy not-in-place : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_convolution(idx<T> &in, idx<T> &ker, idx<T> &out, intg stride_x, intg stride_y) {
    eblerror("th_convolution : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_convolution_3d(idx<T> &in, idx<T> &ker, idx<T> &out) {
    eblerror("th_convolution_3d : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_convolution_3dmap(idx<T> &in, idx<T> &ker, idx<T> &out,
                            idx<intg> &table,
                            intg stride_x, intg stride_y) {
    eblerror("th_convolution_3dmap : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_convolution_3dmap_bprop(idx<T> &inx, idx<T> &kerx,
                                  idx<T> &outdx, idx<T> &indx, 
                                  idx<T> &kerdx, idx<intg> &table,
                                  intg stride_w, intg stride_h) {
    eblerror("th_convolution_3dmap_bprop : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_tanh(idx<T> &in, idx<T> &out) {
    eblerror("th_tanh : type not available for TH. Available types are float32, float64");
  }


  template <typename T>
  void th_pow(idx<T> &in, idx<T> &out, T p) {
    eblerror("th_pow : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_maxpool_3d(idx<T> &in, intg kernel_w, intg kernel_h, idx<T> &out,
                            intg stride_x, intg stride_y, idx<T> &indices_e) {
    eblerror("th_maxpool_3d : type not available for TH. Available types are float32, float64");
  }

  template <typename T>
  void th_maxpool_3d_bprop(idx<T> &inx, intg kernel_w, intg kernel_h,
                                  idx<T> &outdx, idx<T> &indx, 
                                  intg stride_w, intg stride_h, idx<T> &indices_e) {
    eblerror("th_maxpool_3d_bprop : type not available for TH. Available types are float32, float64");
  }


}
#endif /* __TH__ */

#endif /* THOPS_HPP_ */
