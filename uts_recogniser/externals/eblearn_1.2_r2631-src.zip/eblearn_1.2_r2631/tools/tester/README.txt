eblearn_tester

Description:
eblearn_tester is a unit-tester that tests low-level to high-level functions 
of the libeblearn library. 

Execution:
Run eblearn/bin/configure.sh to set-up your mnist directory.
