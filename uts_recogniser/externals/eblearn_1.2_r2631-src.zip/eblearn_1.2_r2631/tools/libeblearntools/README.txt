libeblearn_tools

Description:
A library containing tools for the libeblearn library such as:
  - automatic generation of image databases based on image directories

