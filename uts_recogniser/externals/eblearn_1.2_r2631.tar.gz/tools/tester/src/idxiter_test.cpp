#include "idxiter_test.h"

using namespace std;
using namespace ebl;

void idxiter_test::setUp() {
}

void idxiter_test::tearDown() {
}
