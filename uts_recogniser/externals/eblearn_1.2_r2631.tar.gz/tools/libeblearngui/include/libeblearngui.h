#ifndef LIBEBLEARNGUI_H_
#define LIBEBLEARNGUI_H_

#include "datasource_gui.h"
#include "ebl_arch_gui.h"
#include "ebl_layers_gui.h"
#include "ebl_normalization_gui.h"
#include "ebl_trainer_gui.h"
#include "detector_gui.h"

#endif /* LIBEBLEARNGUI_H_ */
