#ifndef DEFINES_WINDOWS_H_
#define DEFINES_WINDOWS_H_

#ifdef __WINDOWS__
#include <windows.h>							
#include <shellapi.h>						
#include <atlconv.h>						
#endif

#endif /* DEFINES_WINDOWS_H_*/
